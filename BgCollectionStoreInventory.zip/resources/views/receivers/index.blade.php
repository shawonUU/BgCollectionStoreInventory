@php
    $receivers = true;
@endphp
@extends('layouts.app')
@section('content')
    <div class="br-pagebody mg-t-5 pd-x-30">
        <receivers-list></receivers-list>
    </div>
@endsection

