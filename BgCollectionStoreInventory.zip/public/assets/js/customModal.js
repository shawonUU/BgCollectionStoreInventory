let modal  = document.querySelector('.custom-modal');
let button  = document.querySelector('#okHide');
button.addEventListener('click',()=>{

    // document.getElementById("notificationButton").click();
    // console.log(document.getElementById("notificationButton"));
    // modal.style.display='none';
});
