<?php
    $receivers = true;
?>

<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">
        <receivers-list></receivers-list>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/receivers/index.blade.php ENDPATH**/ ?>