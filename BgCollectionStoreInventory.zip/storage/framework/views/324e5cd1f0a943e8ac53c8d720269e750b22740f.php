<?php
    $style_page = true;
?>

<?php $__env->startSection('css'); ?>
    <link href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet" />
    <style>
        .ancor_link{
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">
        <div class="br-section-wrapper mt-4">
            <div class="d-flex justify-content-between  mb-3">
                <div>
                    <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10 ">Search Order wise style</h6>
                </div>
                <div>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-info"><i class="fa fa-arrow-left"></i> Back </a>
                </div>
            </div>
            <div class="row mb-5">
                <div class="col-lg-6 col-xs-6 col-sm-6">
                    <select class="form-control" id="orderId" onchange="redirect()">
                        <option selected disabled hidden value="">--All Order --</option>
                        <?php $__currentLoopData = DB::table('orders')->get(['id', 'order_no']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($order_id == $order->id ? 'selected' : ''); ?>

                                value="<?php echo e(Crypt::encrypt($order->id)); ?>">
                                <?php echo e($order->order_no); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div id="order_table">
                <table class="table table-hover" id="dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Style No</th>
                            <th>Total Accessories</th>
                            <th>Status</th>
                            <th>Created By</th>
                            <th>Updated By</th>
                            <th>Actions </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $style_id = Crypt::encrypt($style->id);
                            ?>
                            <tr class="ancor_link">
                                <th onclick="anchorTag( '<?php echo e(route('inventory.list', $style_id)); ?>' )" scope="row"><?php echo e($loop->iteration); ?></th>
                                <td onclick="anchorTag( '<?php echo e(route('inventory.list', $style_id)); ?>' )"><?php echo e($style->style_no); ?></td>
                                <td onclick="anchorTag( '<?php echo e(route('inventory.list', $style_id)); ?>' )"><?php echo e(total_accessories($style->id)); ?></td>
                                <td>
                                    <a class="btn btn-<?php echo e($style->status == 1 ? 'success' : 'info'); ?> text-capetalize"
                                        href="<?php echo e(route('style_update.status', $style_id)); ?>">
                                        <?php echo e(get_style_status($style->status)); ?></a>
                                </td>
                                <td onclick="anchorTag( '<?php echo e(route('inventory.list', $style_id)); ?>' )" class="text-capitalize"><span
                                        class="badge bg-primary"><?php echo e(get_user_name($style->created_by)); ?></span> </td>
                                <td onclick="anchorTag( '<?php echo e(route('inventory.list', $style_id)); ?>' )" class="text-capitalize"><span
                                        class="badge bg-<?php echo e($style->updated_by ? 'info' : 'secondary'); ?>"><?php echo e($style->updated_by ? get_user_name($style->updated_by) : 'not update'); ?></span>
                                </td>
                                <td>
                                    <div class="dropdown show">
                                        <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                            id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false">
                                            Action
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a href="<?php echo e(route('inventory.list', $style_id)); ?>" class="dropdown-item"><i
                                                    class="fa fa-eye"></i> View Inventories</a>
                                            <?php if(auth()->user()->role_id != 5 && auth()->user()->role_id != 1): ?>
                                                <a href="<?php echo e(route('style.edit', $style_id)); ?>" class="dropdown-item"><i
                                                        class="fa fa-pencil"></i> Edit</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });

        function redirect() {
            var orderId = $('#orderId').val();
            window.location.href = "<?php echo e(route('style.index')); ?>" + '/' + orderId;
        }
        function anchorTag(link){
            window.location.href = link;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/style/index.blade.php ENDPATH**/ ?>