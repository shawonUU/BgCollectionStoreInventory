<a href="<?php echo e(url('/')); ?>" class="br-menu-link <?php echo e(isset($dashboard) ? 'active' : ''); ?> ">
    <div class="br-menu-item">
        <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
        <span class="menu-item-label">Booking</span>
    </div>
</a>

<a href="<?php echo e(route('order_list_for_booking')); ?>" class="br-menu-link <?php echo e(isset($yarn_booking) ? 'active' : ''); ?>">
    <div class="br-menu-item">
        <i class="menu-item-icon icon ion-document-text tx-24"></i>
        <span class="menu-item-label">Yarn Booking</span>

    </div>
</a>

<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/knitting/sidebar.blade.php ENDPATH**/ ?>