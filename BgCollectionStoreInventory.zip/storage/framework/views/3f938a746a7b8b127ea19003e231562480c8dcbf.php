<div class="dropdown show">
    <?php if((auth()->user()->role_id == 2 && auth()->user()->id == $inventory->created_by) or (auth()->user()->role_id==6  or auth()->user()->role_id==3)): ?>
    <a class="btn btn-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        Action
    </a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
        <?php if((auth()->user()->role_id == 2 && auth()->user()->id == $inventory->created_by) or (auth()->user()->role_id==6)): ?>
        <a id="booking_btn" href="<?php echo e(route('boking_histories', Crypt::encrypt($inventory->id))); ?>"
            class="dropdown-item">
            Booking History
        </a>
        <a href="<?php echo e(route('booking.edit', Crypt::encrypt($inventory->id))); ?>" class="dropdown-item">
            Edit Booking
        </a>
        <?php endif; ?>
        <?php if(auth()->user()->role_id == 3 or auth()->user()->role_id ==6): ?>
        <a id="stockin_btn" href="<?php echo e(route('stock_histories', Crypt::encrypt($inventory->id))); ?>"
            class="dropdown-item">
            Stock History
        </a>
        <?php endif; ?>


    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/action_button/inventory_action.blade.php ENDPATH**/ ?>