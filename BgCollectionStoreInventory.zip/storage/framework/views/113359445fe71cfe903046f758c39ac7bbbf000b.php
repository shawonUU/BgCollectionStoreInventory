<div class="br-logo"><a href="<?php echo e(url('/')); ?>"><span>[</span>BG Collection<span>]</span></a></div>
<div class="br-sideleft overflow-y-auto">
    <label class="sidebar-label pd-x-15 mg-t-20">Navigation</label>
    <div class="br-sideleft-menu">
        <?php
            $auth_role = auth()->user()->role_id;
        ?>
        <?php if($auth_role == 1): ?>
            <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($auth_role == 2 or $auth_role == 6): ?>
            <?php echo $__env->make('mr.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($auth_role == 3): ?>
            <?php echo $__env->make('store.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($auth_role == 4 or $auth_role == 3): ?>
            <?php echo $__env->make('stock_out.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($auth_role == 7): ?>
        <?php echo $__env->make('knitting.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('viewers.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(auth()->user()->role_id !=7): ?>
        <a href="<?php echo e(route('inventory.list')); ?>" class="br-menu-link <?php echo e(isset($search_booking) ? 'active' : ''); ?>">
            <div class="br-menu-item">
                <i class="menu-item-icon ion-ios-paper-outline tx-24"></i>
                <span class="menu-item-label">Inventory</span>
            </div>
        </a>
        <?php endif; ?>

    </div>
    <br>
</div>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>