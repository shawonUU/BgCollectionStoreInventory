<table style="width: 100%; margin-top: 10px;">
    <?php $__currentLoopData = $remarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <input class="form-control" style="height: 25px;padding: 2px; border-radius: 0px !important; font-size: 10px;" onchange="updateRemarks(<?php echo e($orderId); ?>,<?php echo e($loop->index); ?>)" type="text"  value="<?php echo e($remark); ?>"id="<?php echo e($loop->index); ?>remarks">
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<button  style="font-size:12px;" class="btn btn-sm btn-primary mb-2 mt-2 py-0" id="addNewFebric" onclick="remarksList(true)">Add New Remarks</button>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/yarn/remarkList.blade.php ENDPATH**/ ?>