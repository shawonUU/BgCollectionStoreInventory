<?php
    // dd($summery);
?>
<style>

    table{
        font-size: 10px;
    }

    td{
        padding: 0px !important;
        margin: 0px !important;
        border: 1px solid #000;
        text-align: center;
    }

    .table-input{
        border: 0;
        width: 100%;
        text-align: center;
        margin: 0px;
        padding: 0px;
        text-align: center;
    }
</style>

<table style="margin-top: 10px;">
    <tbody>
        <?php if(count($summeries)): ?>
            <tr>
                <td>Item</td>
                <td>Fabrica</td>
                <td>Qty(kg)</td>
            </tr>
        <?php endif; ?>
        <?php for($i=0; $i<count($summeries); $i++): ?>
        <tr>
            <td style="border: 1px solid #000; ">
                <div style="text-align: center;">
                        <textarea
                        onmouseup="changeSummeryTextAreaHight(<?php echo e($i); ?>, 'item')"
                        onchange="updateSummery(<?php echo e($i); ?>)"
                        onkeyup="resizeSummeryRealTime(this, <?php echo e($i); ?>, 'item')"
                        id="summery<?php echo e($i); ?>-item" name="summery<?php echo e($i); ?>"
                        class="table-input summeryInput" style="height: 19px; width: 100% !important;"><?php echo e($summeries[$i][0]); ?></textarea>
                </div>
            </td>
            <td style="border: 1px solid #000; ">
                <div style="text-align: center;">
                    <textarea
                    onmouseup="changeSummeryTextAreaHight(<?php echo e($i); ?>, 'fabric')"
                    onchange="updateSummery(<?php echo e($i); ?>)"
                    onkeyup="resizeSummeryRealTime(this, <?php echo e($i); ?>, 'fabric')"
                    id="summery<?php echo e($i); ?>-fabric" class="textArea summeryInput"
                    name="summery<?php echo e($i); ?>"
                    style="height: 19px; width: 100%;border: 0; text-align: center;"><?php echo e($summeries[$i][1]); ?></textarea>
                </div>
            </td>
            <td style="border: 1px solid #000; ">
                <div style="text-align: center; ">
                    <textarea
                    onmouseup="changeSummeryTextAreaHight(<?php echo e($i); ?>, 'qty')"
                    onchange="updateSummery(<?php echo e($i); ?>)"
                    onkeyup="resizeSummeryRealTime(this, <?php echo e($i); ?>, 'qty')"
                    id="summery<?php echo e($i); ?>-qty"
                    type="text" name="summery<?php echo e($i); ?>"
                    class="table-input summeryInput"
                    style="height: 19px; width: 100% !important;"><?php echo e($summeries[$i][2]); ?></textarea>
                </div>
            </td>
        </tr>
        <?php endfor; ?>
    </tbody>
</table>


<button  style="font-size:12px;" class="btn btn-sm btn-primary mb-2 mt-2 py-0" id="addNewFebric" onclick="getSummery(true)">Add New</button>


<script>
    function changeSummeryTextAreaHight(id, tag){
        let  ele = document.getElementById('summery'+id+'-'+tag);
        let height = getComputedStyle(ele)['height'];
        let  item = document.getElementById('summery'+id+'-item');
        let  fabric = document.getElementById('summery'+id+'-fabric');
        let  qty = document.getElementById('summery'+id+'-qty');
        item.style.height = height;
        fabric.style.height = height;
        qty.style.height = height;
    }

    function resizeSummeryRealTime(ele,id, row){
            ele.style.height = 0 +"px";
            ele.style.height = (ele.scrollHeight) + 'px';
            changeSummeryTextAreaHight(id, row);
    }
</script>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/yarn/summeryList.blade.php ENDPATH**/ ?>