<?php
    $users_menu =true;
?>

<?php $__env->startSection('content'); ?>

    <div class="br-pagebody">
        <?php if($trashed_users > 0): ?>
        <a href=<?php echo e(route('trashed_users')); ?>  class="btn btn-danger float-right my-3 mx-3 text-white"><i class="fa fa-trash"></i><span class="pl-2">Recycle Bin(<?php echo e($trashed_users); ?>)</span></a>
        <?php endif; ?>

        <div class="br-section-wrapper">
            <div class="bd rounded table-responsive">
                <table class="table table-hover mg-b-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <?php if(auth()->user()->role_id== 1 or auth()->user()->role_id == 6): ?>
                            <th>Action</th>
                            <?php endif; ?>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if ($user->role_id ==1) {
                                $bg = 'bg-primary';
                            }elseif ($user->role_id ==2) {
                                $bg = 'bg-secondary';
                            }elseif ($user->role_id ==3) {
                                $bg = 'bg-success';
                            }elseif ($user->role_id ==4) {
                                $bg = 'bg-info';
                            }elseif ($user->role_id ==5) {
                                $bg = 'bg-dark';
                            }else{
                                $bg = 'bg-danger';
                            }
                        ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td> <span class="badge <?php echo e($bg); ?>"> <?php echo e($user->role_name); ?></span> </td>
                                <?php if(auth()->user()->role_id == 1 or auth()->user()->role_id == 6): ?>
                                <td>
                                    <div class="dropdown show">
                                        <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                            id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false">
                                            Action
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a href="<?php echo e(route('edit_user', $user->id)); ?>" class="dropdown-item"><i class="fa fa-pencil mg-r-10 pl-2"></i>Edit</a>
                                            <a   href="javascript:void(0)" onclick="deleteItem(<?php echo e($user->id); ?>)" class="dropdown-item"><i class="fa fa-trash pl-2"></i><span class="pl-2">Delete</span></a>

                                            <form id="deleteItem<?php echo e($user->id); ?>" action="<?php echo e(route('delete_user', $user->id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                                <?php endif; ?>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/users/index.blade.php ENDPATH**/ ?>