<?php
    // $users_menu =true;
?>

<?php $__env->startSection('content'); ?>

    <div class="br-pagebody">
        <a href=<?php echo e(route('users')); ?> class="btn btn-primary float-right my-3 mx-3 text-white"><i class="fa fa-user"></i><span class="pl-2">Users List</span></a>
        <div class="br-section-wrapper">

            <div class="bd rounded table-responsive">
                <table class="table table-bordered mg-b-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $trashed_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                               <?php if(isset($user->role->role_name)): ?>
                               <td><?php echo e($user->role->role_name); ?></td>
                               <?php endif; ?>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                                 Action
                                        </button>
                                        <div class="dropdown-menu">
                                            <form id="restoreUser<?php echo e($user->id); ?>" action="<?php echo e(route('restore_user', $user->id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                            <a class="dropdowm-item" onclick="restoreUser(<?php echo e($user->id); ?>)" href="avascript:void(0)" style="color:#000"><i class="fa fa-pencil mg-r-10 pl-2"></i>Restore</a>
                                           </form>
                                            <form id="pdeleteItem<?php echo e($user->id); ?>" action="<?php echo e(route('parmanentlyDelete', $user->id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <a class="dropdowm-item" onclick="pdeleteItem(<?php echo e($user->id); ?>)" href="javascript:void(0)" style="color:#000"><i class="fa fa-trash pl-2"></i><span class="pl-2">Parmanently Delete</span></a>
                                            </form>
                                        </div>
                                      </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="7" class="text-center text-danger">Not Found</td>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div><!-- br-pagebody -->

    <script>
        function restoreUser(id){
            Swal.fire({
                title: 'Are you sure?',
                text: "You you want to restore this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, restore it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#restoreUser' + id).submit()
                }
            })
        }
        function pdeleteItem(id){
            Swal.fire({
                title: 'Are you sure?',
                text: "You you want to permanently this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#pdeleteItem' + id).submit()
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/users/trashed.blade.php ENDPATH**/ ?>