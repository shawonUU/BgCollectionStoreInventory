<?php
    $dashboard = true;
?>

<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">
        <div class="br-section-wrapper mt-4">
            <div class="mb-3 d-flex justify-content-between">
                <div>
                    <?php if($isOrderCreate==0): ?>
                    <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Add Style</h6>
                    <?php else: ?>
                    <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Add Order</h6>
                    <?php endif; ?>
                </div>
                <div>
                    <?php if($isOrderCreate==0): ?>
                    <a class="btn btn-warning" href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-plus"></i> Booking</a>
                    <?php else: ?>
                    <a class="btn btn-warning" href="<?php echo e(route('order_list_for_booking')); ?>"><i class="fa fa-plus"></i> Yarn Booking</a>
                    <?php endif; ?>
                </div>
            </div>
            <form action="<?php echo e(route('style.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" hidden value="<?php echo e($isOrderCreate); ?>" name="isOrderCreate">
                <div class="row">
                    <div class="<?php echo e($isOrderCreate==1?'col-lg-6 col-md-6':'col-lg-4 col-md-4'); ?>">
                        <label class=""><strong>Buyer Name</strong> <span class="text-danger">*</span></label>
                        <select id="buyerId" class="select2 form-control" name="buyer_name">
                            <option value="" selected>--Select Buyer--</option>
                            <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($buyer->id); ?>"><?php echo e($buyer->buyer_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['buyer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="<?php echo e($isOrderCreate==1?'col-lg-6 col-md-6':'col-lg-4 col-md-4'); ?>">
                        <label class=""><strong>Order Number</strong> <span class="text-danger">*</span></label>
                        <?php if(!$isOrderCreate==1): ?>
                            <select id="orderId" class="select2  form-control" name="order_no">
                                
                            </select>
                        <?php else: ?>
                            <select  class="select2 form-control" name="order_no">
                                <option value="" selected>--Select Order--</option>
                            </select>
                        <?php endif; ?>
                        <?php $__errorArgs = ['order_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(!$isOrderCreate==1): ?>
                    <div class="col-lg-4 col-md-4">
                        <label class=""><strong>Style Number</strong> <span class="text-danger">*</span></label>
                        <select id="styleId" class="select2  form-control" name="style_no">
                            
                        </select>
                        
                        <?php $__errorArgs = ['style_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php endif; ?>

                </div>
                <button class="btn btn-primary mt-3" type="submit"> <?php echo submitBtn(); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".select2").select2({
                tags: true
            });
            var buyer_id = $('#buyerId').val();
            get_order(buyer_id);
            get_style();


            function ajaxSetup() {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            }
            $('#buyerId').change(function() {
                var buyer_id = $(this).val();
                get_order(buyer_id);
            });

            function get_order(buyer_id) {
                ajaxSetup();
                $.ajax({
                    type: "post",
                    url: '<?php echo e(route('orders.get')); ?>',
                    data: {
                        buyer_id: buyer_id
                    },
                    success: function(results) {
                        $('#orderId').html(results)
                    }
                });
            }

            function get_style() {
                $.ajax({
                    type: "get",
                    url: '<?php echo e(route('style.get')); ?>',
                    success: function(results) {
                        $('#styleId').html(results)
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/create_style/create.blade.php ENDPATH**/ ?>