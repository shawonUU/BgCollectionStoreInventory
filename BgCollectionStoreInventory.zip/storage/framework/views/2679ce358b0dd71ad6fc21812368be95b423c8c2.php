<?php
    $orderManagement = true;
?>

<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">

        <div class="br-section-wrapper mt-5">
            <div class="d-flex justify-content-end  align-items-center mb-4">
                <div>
                    
                    <a href="<?php echo e(route('download.shifetdorder')); ?>" class="btn btn-sm btn-info text-white"><i
                            class="fa fa-download"></i></i><span class="pl-2">Download</span></a>|
                    

                    <?php if(auth()->user()->role_id == 6): ?>
                        <a href="<?php echo e(route('add.order')); ?>" class="btn btn-sm btn-primary text-white"><i
                                class=""></i><span class="pl-2">Add Order</span></a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('order.management')); ?>" class="ml-2 btn btn-sm btn-warning     text-white"><i
                            class=""></i><span class="pl-2">Running Orders</span>
                    </a>
                </div>
            </div>
            <table class="table" id="datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Job No</th>
                        <th scope="col">Buyer Name</th>
                        <th scope="col">Merchandiser</th>
                        <th scope="col">Fabrication</th>
                        <th scope="col">Order No</th>
                        <th scope="col">Order Qty</th>
                        <th scope="col">Unit Price</th>
                        <th scope="col">Total</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $shiftOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($item->job_no); ?></td>
                            <td><?php echo e($item->buyer_name); ?></td>
                            <td><?php echo e($item->merchandiser); ?></td>
                            <td><?php echo e($item->fabrication); ?></td>
                            <td><?php echo e($item->order_no); ?></td>
                            <td><?php echo e($item->order_qty); ?></td>
                            <td><?php echo e($item->unit_price); ?></td>
                            <td><?php echo e($item->total); ?></td>
                            <td><?php echo e($item->status); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit.shifted.order', encrypt($item->id))); ?>" style="color:black">
                                    <i class="fa fa-pencil-square" style="font-size:20px"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            // alert('hello');
            $("#buyerSelect").select2({
                tags: true
            });
            $("#status").select2({
                tags: true
            });

        });
        $("#datatable").DataTable();

        function editModal() {

            // alert('hello');
            // let id = $('#'+'style_no').val();
            // $('#'+'styleSeeder').val(id);
            // document.getElementById('styleSeeder').dispatchEvent(new Event('change'));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/order_management/shiftOrder.blade.php ENDPATH**/ ?>