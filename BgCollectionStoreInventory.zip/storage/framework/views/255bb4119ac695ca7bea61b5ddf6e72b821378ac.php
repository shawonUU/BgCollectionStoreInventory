<div class="br-section-wrapper mt-4">
    <div class="d-flex justify-content-between">
        <div>
            <h3 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Inventory of <span class="text-info">
                    <?php echo e($style->style_no); ?></span></h3>
        </div>
    </div>
    <div id="booking_info">
        <div id="stock_in_section"  class="table-responsive">
            <?php if($inventories->count()): ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Accessories Name</th>
                            <th scope="col">Unit</th>
                            <th scope="col">Color Name</th>
                            <th scope="col">Size</th>
                            <th scope="col">Garments Quantity</th>
                            <th scope="col">Requered Quantity</th>
                            <th scope="col">Received Quantity</th>
                            <th scope="col">Balance</th>
                            <th scope="col">Stock Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $requered_quantity =  $inventory->requered_quantity;
                            $received_quantity =  $inventory->received_quantity;
                            $balance =   $received_quantity  - $requered_quantity;
                            $stock_quantity =  $inventory->stock_quantity ;
                        ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($inventory->accessories_name); ?></td>
                                <td><?php echo e($inventory->unit); ?></td>
                                <td><?php echo e($inventory->color_name); ?></td>
                                <td><?php echo e($inventory->size); ?></td>
                                <td><?php echo e(floatFormater($inventory->garments_quantity)); ?></td>
                                <td><?php echo e(floatFormater($requered_quantity)); ?></td>
                                <td><span class="badge bg-<?php echo e($received_quantity >= $requered_quantity ? 'secondary' : 'danger'); ?> "><?php echo e(floatFormater($received_quantity)); ?> </span></td>

                                <td> <span class="badge bg-<?php echo e($balance > 0 ? 'info' : 'danger'); ?> "><?php echo e(floatFormater($balance)); ?> </span></td>
                                <td> <span class="badge bg-<?php echo e($stock_quantity > 0 ? 'success' : 'warning'); ?> "><?php echo e(floatFormater($stock_quantity)); ?> </span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php else: ?>
                <h5 class="text-center text-danger text-capitalize mt-4 "> booking or inventory not found</h5>
            <?php endif; ?>

        </div>
    </div>
</div>



<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/store/style_wise_inventory.blade.php ENDPATH**/ ?>