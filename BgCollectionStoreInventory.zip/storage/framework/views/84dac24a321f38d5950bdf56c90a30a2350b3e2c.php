<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Bg Collection Store Mangement Application</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/BG-Collection-logo-.png')); ?>">

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bracket.css')); ?>">
    <style>
        .is-invalid {
            outline: 1px solid #d63384;
        }
    </style>
</head>

<body>
    <div class="d-flex align-items-center justify-content-center bg-br-primary ht-100v">
        <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base">
            <div class="signin-logo tx-center tx-28 tx-bold tx-inverse"><span class="tx-normal">[</span> Bg Collection
                <span class="tx-normal">]</span>
            </div>
            <div class="tx-center mg-b-60">User Login</div>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                        autofocus class="form-control" placeholder="Enter your email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                        required autocomplete="current-password" placeholder="Enter your password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label class="d-flex align-items-center">
                        <div>
                            <input class="custom-control" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        </div>
                        <div>
                            <p class="tx-info tx-15 d-block mg-t-10">Remember Me</p>
                        </div>
                    </label>
                </div>
                <button type="submit" class="btn btn-info btn-block">Sign In</button> 
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/auth/login.blade.php ENDPATH**/ ?>