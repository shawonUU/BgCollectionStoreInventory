<div class="br-header">
    <div class="br-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i
                    class="icon ion-navicon-round"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i
            class="icon ion-navicon-round"></i></a></div>
      </div>
    <div class="br-header-right">
        <nav class="nav">
            
            <?php if(auth()->user()->role_id == 2 or auth()->user()->role_id == 3 or auth()->user()->role_id == 6): ?>
            <div class="dropdown">
                <a id="notificationButton" onclick="seenNotification()" href="" class="nav-link pd-x-7 pos-relative" data-toggle="dropdown" >
                    <i class="icon ion-ios-bell-outline tx-24"></i>
                    <?php if(notificationSeenStatus()): ?>
                    <span class="square-8 bg-danger pos-absolute t-15 r-5 rounded-circle"></span>
                    <?php endif; ?>
                </a>
                 <div class="dropdown-menu dropdown-menu-header wd-300 pd-0-force " >
                    <div class="d-flex align-items-center justify-content-between pd-y-10 pd-x-20 bd-b bd-gray-200">
                        <label class="tx-12 tx-info tx-uppercase tx-semibold tx-spacing-2 mg-b-0">Notifications </label>
                        <?php if(unreadNotification()): ?>
                        <a href="" class="tx-11">Mark All as Read</a>
                        <?php endif; ?>
                    </div>
                    <div class="media-list" style="max-height:250px; overflow-y:auto">

                        <?php $__empty_1 = true; $__currentLoopData = showNotification(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $notification_style = Crypt::encrypt($notification->style_id);
                                $notification_id = Crypt::encrypt($notification->id);
                                if ($notification->effected_accessories) {
                                    $message = $notification->effected_accessories.' '. $notification->message.' '.$notification->style_no;
                                }else{
                                    $message = $notification->message.' '.$notification->style_no;
                                }

                                $url = route('inventory.list', $notification_style).'?n_id='.$notification_id;
                            ?>

                        <a href="<?php echo e($url); ?>" class="media-list-link read">
                            <div class="media pd-x-20 pd-y-15 <?php echo e($notification->status==0?'bg-grey':'bg-white'); ?>" >
                                <div class="media-body">
                                    <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium tx-gray-800"><?php echo e($message); ?></strong></p>
                                    <span class="tx-12 text-right"><?php echo e($notification->updated_at->diffForHumans()); ?></span>

                                </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="media pd-x-20 pd-y-15" >
                                <div class="media-body text-center">
                                    <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium text-danger ">No Notification</strong></p>

                                </div>
                            </div>
                        <?php endif; ?>
                        
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="dropdown">
                <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
                    <span class="logged-name hidden-md-down"><?php echo e(auth()->user()->name); ?></span>
                    <img src="<?php echo e(asset('assets/img/dummy-profile.jpeg')); ?>" class="wd-32 rounded-circle" alt="">
                    <span class="square-10 bg-success"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-header wd-200">
                    <ul class="list-unstyled user-profile-nav">
                        <li><a href="<?php echo e(route('password.change')); ?>"><i class="icon ion-ios-gear"></i> Change Password</a></li>
                        <li>
                            <form id="logout_form" action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <a href="javascript:void(0)" onclick="document.getElementById('logout_form').submit();"><i
                                        class="icon ion-power"></i> Sign Out</a>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/layouts/nav.blade.php ENDPATH**/ ?>