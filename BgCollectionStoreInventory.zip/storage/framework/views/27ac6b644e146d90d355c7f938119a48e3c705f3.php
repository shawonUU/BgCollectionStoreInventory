<?php
    // $yarnBooking = true;
?>


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
<style>
    /* html { overflow: hidden!important; } */
      table{
          font-size: 10px;
      }
      td{
          padding: 0px !important;
          margin: 0px !important;
          border: 1px solid #000;
          text-align: center;
      }

      .table-input{
          border: 0;
          width: 100%;
          text-align: center;
          margin: 0px;
          padding: 0px;
          text-align: center;
      }

      input[type=checkbox]{
          cursor: pointer;
      }

    /* Chrome, Safari, Edge, Opera */
      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
      }

      /* Firefox */
      input[type=number] {
      -moz-appearance: textfield;
      }

      div.scroll {
              width: 100%;
              overflow-x: auto;
              overflow-y: hidden;
              white-space: nowrap;
      }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
    $col = count($fabrications);
    $row = count($combos);
    $col2 = 11+($col*2);
    $title = ['Fabrication:', 'Item:', 'Fabrics For:', 'Finished Cos/Dzn:', 'Req Finished GSM:', 'Req Finished DIA:', 'Allocated Yarn Count:', 'Process Loss:'];
    $fabricationColums = ['fabrication','item','fabric_for', 'cos_dzn', 'gsm', 'dia', 'yarn_count', 'process_loss'];
    $width = 60;
    $margin = 305;
    $divWidth = ((60*($col2-1)) + 60 + $col2);
?>









   <div class="d-print-none" style="display: flex; justify-content: end;">
        
        <a href="<?php echo e(route('print_booking_sheet', $orderId)); ?>" class="btn btn-sm btn-warning text-white shadow-none"
            target="_blank"><i class="fa fa-print"></i> Print</a>
   </div>

   <div id="myTable">
        <div  class="scroll" style="color: black;">
            <div class="ml-3">
                <div style="padding-top: 100px !important; width: <?php echo e($divWidth); ?>px !important;">
                    <div style="margin-left: <?php echo e($margin); ?>px; display: inline-flex; position: relative;">
                    
                     <div style="width: 100%; display: block; text-align: center; font-size: 12px; position: absolute; top:-100px; left: 0;">

                        <span style="display: block; font-size: 14px;">BG COLLECTION ltd.</span><br>
                        <span  >Baniarchala, Bhabanipur, Gazipur</span><br>
                        <span >
                            REVISED
                            <span><?php echo e($yarnBooking->revised); ?></span>
                             BULK BOOKING
                        </span><br>
                        
                        <span style="text-align: center; text-transform:uppercase;"><?php echo e($yarnBooking->hrader_text); ?></span>

                    </div>
                    <div style="display:inline; font-size: 12px; position: absolute; top:-62px; left: -215px;">
                        <div style="display:inline">
                        <table class="">
                            <tr>
                            <td class="px-2">Buyer: </td>
                            <td>
                                <input style="border:none; outline: none;" readonly type="text" value="<?php echo e($orderInfo->buyer_name); ?>">
                            </td>
                            </tr>
                            <tr>
                            <td class="px-2">Order No:</td>
                            <td>
                                <textarea id="orderNo" style="border:none; height: 19px !important;" readonly type="text" ><?php echo e($orderInfo->order_no); ?></textarea>
                            </td>
                            </tr>
                            <tr>
                            <td class="px-2">Order Qty:</td>
                            <td>
                                <input style="border:none;outline: none;" min="0" step="0.1" type="number" id="order_qty" value="<?php echo e($yarnBooking->order_qty??""); ?>" readonly>
                            </td>
                            </tr>
                        </table>
                        </div>
                    </div>
                    <div style="display:inline;font-size: 12px; position: absolute; top:-45px; right:-185px;">
                        <div style="display:inline">
                        <table class="">
                            <tr>
                                <td class="px-2">Issue Date: </td>
                                <td>
                                    <input style="border:none; outline: none;" type="date" value="<?php echo e($yarnBooking->issuing_date??""); ?>" id="issuing_date" readonly>
                                </td>
                            </tr>
                            <tr>
                                <td class="px-2">Shipment Date:</td>
                                <td>
                                    <input style="border:none; outline: none;" type="date" value="<?php echo e($yarnBooking->shipment_date??""); ?>" id="shipment_date" readonly>
                                </td>
                            </tr>
                        </table>
                        </div>
                    </div>
                    <table style="width: 100% !important;">
                        <tbody>
                            <?php for($i=0; $i <8; $i++): ?>
                                <tr>
                                    <td style="border: 1px solid #000; ">
                                        <div style="text-align: center; width: <?php echo e($width*3+1); ?>px !important;">
                                            <?php echo e($title[$i]); ?>

                                        </div>
                                    </td>
                                    <?php for($j=0; $j<$col; $j++): ?>
                                        <td style="border: 1px solid #000; ">
                                            <div style="text-align: center; width: <?php echo e($width*2+1); ?>px !important;">
                                                <?php if($i==0 || $i == 6 || $i == 2): ?>
                                                    <textarea class="textArea" id="fabric<?php echo e($fabrications[$j]['id']); ?>-<?php echo e($fabricationColums[$i]); ?>"
                                                    name="<?php echo e($fabricationColums[$i]); ?>"
                                                    style="height: 19px !important; width: 100%;border: 0; text-align: center;" onmouseup="changeTextAreaHight(<?php echo e($fabrications[$j]['id']); ?>, '<?php echo e($fabricationColums[$i]); ?>')" readonly><?php echo e($fabrications[$j][$fabricationColums[$i]]); ?></textarea>
                                                <?php else: ?>
                                                    <input style="outline: none;" id="fabric<?php echo e($fabrications[$j]['id']); ?>-<?php echo e($fabricationColums[$i]); ?>" type="<?php echo e($fabricationColums[$i]=='cos_dzn'? 'number':($fabricationColums[$i]=='gsm'? 'number':($fabricationColums[$i]=='process_loss'? 'number':'text'))); ?>" value="<?php echo e($fabrications[$j][$fabricationColums[$i]]); ?>" class="table-input" readonly>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    <?php endfor; ?>
                                </tr>
                            <?php endfor; ?>
                    </tbody>
                    </table>
                    </div>
                    <table style="margin-top: 5px;">
                    <tbody>
                        <tr style="padding: 0;">
                            <td>Combo</td>
                            <td>Color</td>
                            <td>LD No</td>
                            <td>Shade</td>
                            <td>O.Qty</td>
                            <td>E.Cut</td>
                            <td>N.Qty</td>
                            <?php for($j=0; $j<$col; $j++): ?>
                                <td>R.Fini</td>
                                <td>R.Gray</td>
                            <?php endfor; ?>
                            <td>T.Fini</td>
                            <td>T.Gray</td>
                            <td>R.mrks</td>
                        </tr>
                        <?php for($i=0; $i<$row; $i++): ?>
                        <?php $yarnAllocations=$combos[$i]['yarnAllocations'];
                            $allocationId=0;
                            $fabricCol=0;
                            $fabricDx=0;
                        ?>
                        <tr style="padding: 0;">
                            <?php for($j=0; $j<$col2; $j++): ?>
                            <?php if($j==0): ?>
                            <?php elseif($j <8 || $col2-4<$j): ?>
                                <?php $readonly=false;
                                    if($j-1==0) {$comboId="combo" .$combos[$i]['id']."-combo"; $comboColumn="combo" ; $type='text' ; }
                                    if($j-1==1) { $comboId="combo" .$combos[$i]['id']."-color"; $comboColumn="color" ;$type='text' ;}
                                    if($j-1==2) {$comboId="combo" .$combos[$i]['id']."-ld"; $comboColumn="ld_no" ;$type='text' ;}
                                    if($j-1==3) { $comboId="combo" .$combos[$i]['id']."-shade"; $comboColumn="shade" ;$type='text' ;}
                                    if($j-1==4) {$comboId="combo" .$combos[$i]['id']."-qty";$comboColumn="qty" ;$type='number' ;}
                                    if($j-1==5) {$comboId="combo" .$combos[$i]['id']."-ecut"; $comboColumn="extra_cutting" ;$type='number' ;}
                                    if($j-1==6) {$comboId="combo" .$combos[$i]['id']."-nqty"; $comboColumn="new_qty" ;$type='number' ;}
                                    if($j==$col2-3) {$readonly=true;$comboId="combo" .$combos[$i]['id']."-tf"; $comboColumn="total_finished" ;$type='number' ;}
                                    if($j==$col2-2) {$readonly=true;$comboId="combo" .$combos[$i]['id']."-tg"; $comboColumn="total_gray" ;$type='number' ;}
                                    if($j==$col2-1) {$comboId="combo" .$combos[$i]['id']."-rmk"; $comboColumn="remarks" ;$type='text' ;}
                                ?>
                                <td>
                                    <div style="text-align: center; width: <?php echo e($j==2? $width*2:$width); ?>px !important;">
                                        <input style="outline: none;" id="<?php echo e($comboId); ?>" type="<?php echo e($type); ?>" value="<?php echo e($combos[$i][$comboColumn]); ?>" class="table-input" readonly>
                                    </div>
                                </td>
                            <?php else: ?>
                                <?php
                                    $fabricId = $fabrications[$fabricCol]['id'];
                                    if($j%2==0) $comboId = "combo".$combos[$i]['id']."-fabric".$fabrications[$fabricCol]['id']."-rf";
                                    if($j%2==1) $comboId = "combo".$combos[$i]['id']."-fabric".$fabrications[$fabricCol++]['id']."-rg";
                                    $yarnAllocationsColumnValue = null;
                                    $readonly = 'readonly';
                                    if(isset($yarnAllocations[$allocationId]) && $yarnAllocations[$allocationId]['fabric_id'] == $fabrications[$fabricDx]['id']){
                                        if($j%2==0) $yarnAllocationsColumnValue = $yarnAllocations[$allocationId]['req_finished'];
                                        if($j%2==1) {
                                            $yarnAllocationsColumnValue = $yarnAllocations[$allocationId]['req_gray'];
                                            $allocationId++;
                                        }
                                        $readonly = null;
                                    }
                                    if($j%2==1) $fabricDx++;
                                ?>
                                <td>
                            <div style="text-align: center; width: <?php echo e($width); ?>px !important;">
                                <input style="outline: none;" id="<?php echo e($comboId); ?>" type="number" value="<?php echo e($yarnAllocationsColumnValue); ?>" class="table-input" readonly>
                            </div>
                            </td>
                            <?php endif; ?>
                            <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                        <tr>
                            <?php
                                $fabricCol = 0;
                                $tf = 0;
                                $tg = 0;
                            ?>
                            <?php for($j=0; $j<$col2-7; $j++): ?>
                                <?php if($j==0): ?>
                                <td colspan="7">Total</td>
                                    <?php elseif($j<$col2-10): ?>
                                    <?php
                                    if($j%2==1){
                                        $id=$fabrications[$fabricCol]['id']."-tf";
                                        $vlo=$fabrications[$fabricCol]['total_finished'];
                                        $tf +=$vlo;
                                        }
                                        if($j%2==0){
                                            $id=$fabrications[$fabricCol]['id']."-tg";
                                            $vlo=$fabrications[$fabricCol++]['total_gray'];
                                            $tg +=$vlo;
                                        }
                                        ?>
                                        <td>
                                <div style="text-align: center; width: <?php echo e($width); ?>px !important;">
                                    <input style="outline: none;" id="<?php echo e($id); ?>" type="number" value="<?php echo e($vlo); ?>" class="table-input" readonly>
                                </div>
                                </td> <?php elseif($j<$col2-8): ?> <?php if($j%2==1){$id='tf' ; $vlo=$tf;} if($j%2==0){$id='tg' ; $vlo=$tg;} ?> <td>
                                    <div style="text-align: center; width: <?php echo e($width); ?>px !important;">
                                        <input style="outline: none;" id="<?php echo e($id); ?>" type="number" value="<?php echo e($vlo); ?>" class="table-input" readonly>
                                    </div>
                                </td>
                                <?php else: ?>
                                    <td></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </tr>
                        <tr></tr>
                    </tbody>
                    </table>


                    <div>
                        <p class="d-inline" style="font-size: 10px; padding: 0px; margin-top: 5px;"> Booking Based On Knitting & Dyeing Process Loss <span style="font-size: 12px; font-weight: bold;">
                            <?php echo e($yarnBooking->process_loss??""); ?>% </span> Extra Cutting- <span style="font-size: 12px; font-weight: bold;">
                            <?php echo e($yarnBooking->extra_cutting??""); ?>% </span>
                        </p>
                        <div class="row">
                            <div class="col-4" style="font-size:12px;">
                                <p style="font-size: 12px; color: black; margin-top: 10px;">
                                <span>1. Please strictly maintain the above mentioned DIA & GSM</span>
                                <br>
                                <span>2. Color Fastness, rubbing and chemical test should be Pass.</span>
                                <br>
                                <span>3. SHRINKAGE & GSM ALLOW BELLOW ±5% (After wash)***</span>
                                </p>
                            </div>
                            <div class="col-4" style="font-size:12px;">
                                <div id="remarkList">
                                    <table style="width: 100%; ">
                                        <?php $__currentLoopData = $remarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input class="form-control" style="height: 25px;padding: 2px; border-radius: 0px !important; font-size: 10px; outline: none !important; " type="text" value="<?php echo e($remark); ?>" id="<?php echo e($loop->index); ?>remarks" readonly>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                            <div class="col-4 d-flex" style="font-size:12px; justify-content: end;">
                                <table >
                                    <tbody>
                                        <?php if(count($summeries)): ?>
                                            <tr>
                                                <td>Item</td>
                                                <td>Fabrica</td>
                                                <td>Qty(kg)</td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php for($i=0; $i<count($summeries); $i++): ?>
                                        <tr>
                                            <td style="border: 1px solid #000; ">
                                                <div style="text-align: center;">
                                                        <textarea onmouseup="changeSummeryTextAreaHight(<?php echo e($i); ?>, 'item')" name="summery<?php echo e($i); ?>"  id="summery<?php echo e($i); ?>-item" type="text"  class="table-input summeryInput" style="outline: none;height: 19px !important;" readonly><?php echo e($summeries[$i][0]); ?></textarea>
                                                </div>
                                            </td>
                                            <td style="border: 1px solid #000; ">
                                                <div style="text-align: center;">
                                                    <textarea onmouseup="changeSummeryTextAreaHight(<?php echo e($i); ?>, 'fabric')" name="summery<?php echo e($i); ?>" id="summery<?php echo e($i); ?>-fabric" class="textArea summeryInput" name="" style="outline: none; height: 19px; width: 100%;border: 0; text-align: center;" readonly><?php echo e($summeries[$i][1]); ?></textarea>
                                                </div>
                                            </td>
                                            <td style="border: 1px solid #000; ">
                                                <div style="text-align: center; ">
                                                    <textarea onmouseup="changeSummeryTextAreaHight(<?php echo e($i); ?>, 'qty')" name="summery<?php echo e($i); ?>" id="summery<?php echo e($i); ?>-qty" type="text"  class="table-input summeryInput" style="outline: none;height: 19px !important;" readonly><?php echo e($summeries[$i][2]); ?></textarea>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endfor; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="row"  style="font-size:11px;color:black; margin-top: 30px;  margin-bottom: 20px;">
                            <div class="col"><u>Asst.Marchandiser</u></div>
                            <div class="col"><u>Marchandiser</u></div>
                            <div class="col"><u>Store(inc)</u></div>
                            <div class="col"><u>Manager(Knitting)</u></div>
                            <div class="col"><u>Senior DGM(MM)</u></div>
                            <div class="col"><u>Executive Director</u></div>
                            <div class="col"><u>Director</u></div>
                          </div>
                    </div>


                </div>
            </div>
            </div>
        </div>

   </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

        var maxHight = 0;
        textAreaHightResize();


        function changeSummeryTextAreaHight(id, tag){
            let  ele = document.getElementById('summery'+id+'-'+tag);
            let height = getComputedStyle(ele)['height'];
            let  item = document.getElementById('summery'+id+'-item');
            let  fabric = document.getElementById('summery'+id+'-fabric');
            let  qty = document.getElementById('summery'+id+'-qty');

            item.style.height = height;
            fabric.style.height = height;
            qty.style.height = height;

        }


        function changeTextAreaHight(j, row){
            var ele = document.getElementById('fabric' + j + '-' + row);
            var height = getComputedStyle(ele)['height'];
            collection = document.getElementsByClassName("textArea");
            for (let i = 0; i < collection.length; i++) {
                if (collection[i].name == row) {
                    collection[i].style.height = height;
                }
            }
        }

        function saveAsPdf(){
            var pdf = new jsPDF();
            pdf.addHTML(document.getElementById('myTable'), function() {
                pdf.save('table.pdf');
            });
        }

        function changeSummeryTextAreaHight(id, tag){
            let  ele = document.getElementById('summery'+id+'-'+tag);
            let height = getComputedStyle(ele)['height'];
            let  item = document.getElementById('summery'+id+'-item');
            let  fabric = document.getElementById('summery'+id+'-fabric');
            let  qty = document.getElementById('summery'+id+'-qty');

            item.style.height = height;
            fabric.style.height = height;
            qty.style.height = height;

        }

        function textAreaHightResize(){
            let elements = document.getElementsByTagName("textarea");
                let fabricMaxHighets = {};
                for (let i = 0; i < elements.length; i++) {
                    let ele = elements[i];
                    if (ele.id != 'orderNo' && !ele.classList.contains("summeryInput")) {
                        ele.style.height = (ele.scrollHeight) + 'px';

                        if (!fabricMaxHighets[ele.name]) fabricMaxHighets[ele.name] = 0;

                        if (fabricMaxHighets[ele.name] < ele.scrollHeight) {
                            fabricMaxHighets[ele.name] = ele.scrollHeight;
                        }
                    }

                }

                for (let i = 0; i < elements.length; i++) {
                    let ele = elements[i];
                    if (ele.id != 'orderNo' && !ele.classList.contains("summeryInput")) {
                        ele.style.height = fabricMaxHighets[ele.name] + 'px';
                    }
                }

                var ele = document.getElementById('orderNo');
                ele.style.height = (ele.scrollHeight) + 'px';

                let elements1 = document.getElementsByClassName("summeryInput");

                let maxHighets = {};

                for (let i = 0; i < elements1.length; i++) {
                    let ele = elements1[i];
                    if (!maxHighets[ele.name]) {
                        maxHighets[ele.name] = 0;
                    }
                    if (maxHighets[ele.name] < ele.scrollHeight) {
                        maxHighets[ele.name] = ele.scrollHeight;
                    }
                }
                for (let i = 0; i < elements1.length; i++) {
                    let ele = elements1[i];
                    ele.style.height = 'auto';
                    ele.style.height = maxHighets[ele.name] + 'px';
                }
            }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/viewers/bookingView.blade.php ENDPATH**/ ?>