<?php
    $col = count($fabrications);
    $row = count($combos);
    $col2 = 11 + $col * 2;
    $title = ['Fabrication:', 'Item:', 'Fabrics For:', 'Finished Cos/Dzn:', 'Req Finished GSM:', 'Req Finished DIA:', 'Allocated Yarn Count:', 'Process Loss:'];
    $fabricationColums = ['fabrication', 'item', 'fabric_for', 'cos_dzn', 'gsm', 'dia', 'yarn_count', 'process_loss'];
    $width = 60;
    $margin = 336;
    $divWidth = 60 * $col2 - 60 / 2 + 60 + $col2;
?>


<style>
    table {
        font-size: 10px;
    }

    td {
        padding: 0px !important;
        margin: 0px !important;
        border: 1px solid #000;
        text-align: center;
    }

    .table-input {
        border: 0;
        width: 100%;
        text-align: center;
        margin: 0px;
        padding: 0px;
        text-align: center;
    }

    input[type=checkbox] {
        cursor: pointer;
    }

    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* Firefox */
    input[type=number] {
        -moz-appearance: textfield;
    }

    div.scroll {
        width: 100%;
        overflow-x: auto;
        overflow-y: hidden;
        white-space: nowrap;
    }
</style>







<div class="d-flex justify-content-end  align-items-center">
    <div>
        <a href="<?php echo e(route('print_booking_sheet', $orderId)); ?>" class="btn btn-sm btn-warning text-white shadow-none"
            target="_blank"><i class="fa fa-print"></i> Print</a>
    </div>
</div>
<div class="scroll" style="color: black;">
    <div class="">
        <div style="padding-top: 100px !important; Width:<?php echo e($divWidth); ?>px !important;">
            <div style="margin-left: <?php echo e($margin); ?>px; display: inline-flex; position: relative;">
                <div
                    style="width: 100%; display: block; text-align: center; font-size: 12px; position: absolute; top:-105px; left: 0;">

                    <span style="display: block; font-size: 14px;">BG COLLECTION ltd.</span><br>
                    <span>Baniarchala, Bhabanipur, Gazipur</span><br>
                    <span>
                        REVISED
                        <span><input type="text" value="<?php echo e($yarnBooking->revised); ?>" id="revised"
                                onkeyup="changeYarnBookingHearderData(<?php echo e($orderId); ?>)"
                                style="width: 30px; background-color: #E9ECEF; outline: none; border: none; border-bottom: 1px solid #363637; "></span>
                        BULK BOOKING
                    </span><br>
                    
                    <span><input type="text" value="<?php echo e($yarnBooking->hrader_text); ?>" id="hrader_text"
                            onchange="changeYarnBookingHearderData(<?php echo e($orderId); ?>)"
                            style="background-color: #E9ECEF; text-align:center; text-transform:uppercase; outline: none; border: none; border-bottom: 1px solid #363637;"></span>

                </div>
                <div style="display:inline; font-size: 12px; position: absolute; top:-62px; left: -215px;">
                    <div style="display:inline">
                        <table class="">
                            <tr>
                                <td class="px-2">Buyer: </td>
                                <td><input style="border:none; width: 100%;" readonly type="text"
                                        value="<?php echo e($orderInfo->buyer_name); ?>"></td>
                            </tr>
                            <tr>
                                <td class="px-2">Order No:</td>
                                <td>
                                    <textarea id="orderNo" style="border:none; height: 17px !important;" readonly type="text"><?php echo e($orderInfo->order_no); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <td class="px-2">Order Qty:</td>
                                <td><input style="border:none; width: 100%;" min="0" step="0.1"
                                        onchange="changeYarnBookingData(<?php echo e($orderId); ?>)" type="number"
                                        id="order_qty" value="<?php echo e(floatFormater($yarnBooking->order_qty ?? '')); ?>"></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div style="display:inline;font-size: 12px; position: absolute; top:-45px; right:-185px;">
                    <div style="display:inline">
                        <table class="">
                            <tr>
                                <td class="px-2">Issue Date: </td>
                                <td><input style="border:none" onchange="changeYarnBookingData(<?php echo e($orderId); ?>)"
                                        type="date" value="<?php echo e($yarnBooking->issuing_date ?? ''); ?>" id="issuing_date">
                                </td>
                            </tr>
                            <tr>
                                <td class="px-2">Shipment Date:</td>
                                <td><input style="border:none" onchange="changeYarnBookingData(<?php echo e($orderId); ?>)"
                                        type="date" value="<?php echo e($yarnBooking->shipment_date ?? ''); ?>"
                                        id="shipment_date"></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <button class="btn btn-primary " style="position: absolute; top:0; right:-35px;"
                    onclick="getTable(null,true)">+</button>
                <table>
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #000; text-align: center;">Select fabric =></td>
                            <?php for($j = 0; $j < $col; $j++): ?>
                                <td style="border: 1px solid #000; ">
                                    <div style="text-align: center; width: <?php echo e($width * 2 + 1); ?>px !important;">
                                        <input onchange="setUnsetFabric(<?php echo e($fabrications[$j]['id']); ?>)"
                                            id="fabric<?php echo e($fabrications[$j]['id']); ?>-check" type="checkbox"
                                            class="checkBox table-input">
                                    </div>
                                </td>
                            <?php endfor; ?>
                        </tr>
                        <?php for($i = 0; $i < 8; $i++): ?>
                            <tr>
                                <td style="border: 1px solid #000; ">
                                    <div style="text-align: center; width: <?php echo e($width * 3 + 1); ?>px !important;">
                                        <?php echo e($title[$i]); ?>

                                    </div>
                                </td>
                                <?php for($j = 0; $j < $col; $j++): ?>
                                    <td style="border: 1px solid #000; ">
                                        <div style="text-align: center; width: <?php echo e($width * 2 + 1); ?>px !important;">

                                            <?php if($i == 0 || $i == 6 || $i == 2): ?>
                                                <textarea 
                                                    onkeydown="moveMouseFocus(this,event, 'fabric', <?php echo e($fabrications[$j]['id']); ?>, '<?php echo e($i); ?>')"
                                                     name="<?php echo e($fabricationColums[$i]); ?>" class="textArea"
                                                    onchange="changefabrication(<?php echo e($fabrications[$j]['id']); ?> , '<?php echo e($fabricationColums[$i]); ?>')"
                                                    id="fabric<?php echo e($fabrications[$j]['id']); ?>-<?php echo e($fabricationColums[$i]); ?>"
                                                    style="height: 19px !important; width: 100%;border: 0; text-align: center;"
                                                    onkeyup="resizeRealTime(this, <?php echo e($fabrications[$j]['id']); ?>, '<?php echo e($fabricationColums[$i]); ?>', event)"
                                                    onmouseup="changeTextAreaHight(<?php echo e($fabrications[$j]['id']); ?>, '<?php echo e($fabricationColums[$i]); ?>')"><?php echo e($fabrications[$j][$fabricationColums[$i]]); ?></textarea>
                                            <?php else: ?>
                                                <input
                                                    onchange="changefabrication(<?php echo e($fabrications[$j]['id']); ?>, '<?php echo e($fabricationColums[$i]); ?>' )"
                                                    id="fabric<?php echo e($fabrications[$j]['id']); ?>-<?php echo e($fabricationColums[$i]); ?>"
                                                    type="<?php echo e($fabricationColums[$i] == 'cos_dzn' ? 'number' : ($fabricationColums[$i] == 'gsm' ? 'number' : ($fabricationColums[$i] == 'process_loss' ? 'number' : 'text'))); ?>"
                                                    value="<?php echo e(floatFormater($fabrications[$j][$fabricationColums[$i]])); ?>"
                                                    class="table-input"
                                                    onkeydown="moveMouseFocus(this,event, 'fabric', <?php echo e($fabrications[$j]['id']); ?>, '<?php echo e($i); ?>')"
                                                    onkeyup="releaseShiftPress()"
                                                    >
                                            <?php endif; ?>

                                        </div>
                                    </td>
                                <?php endfor; ?>
                            </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
            </div>



            <table style="margin-top: 5px;">
                <tbody>
                    <tr style="padding: 0;">
                        <td>Select</td>
                        <td>Combo</td>
                        <td>Color</td>
                        <td>LD No</td>
                        <td>Shade</td>
                        <td>O.Qty</td>
                        <td>E.Cut</td>
                        <td>N.Qty</td>
                        <?php for($j = 0; $j < $col; $j++): ?>
                            <td>R.Fini</td>
                            <td>R.Gray</td>
                        <?php endfor; ?>
                        <td>T.Fini</td>
                        <td>T.Gray</td>
                        <td>R.mrks</td>
                    </tr>
                    <?php for($i = 0; $i < $row; $i++): ?>
                        <?php
                            $yarnAllocations = $combos[$i]['yarnAllocations'];
                            $allocationId = 0;
                            $fabricCol = 0;
                            $fabricDx = 0;
                        ?>
                        <tr style="padding: 0;">
                            <?php for($j = 0; $j < $col2; $j++): ?>
                                <?php if($j == 0): ?>
                                    <td>
                                        <div style="text-align: center; width: <?php echo e($width / 2); ?>px !important;">
                                            <input value="<?php echo e($combos[$i]['id']); ?>"
                                                onchange="getSelectedFabricItem(<?php echo e($combos[$i]['id']); ?>, 'combo<?php echo e($i); ?>-check')"
                                                id="combo<?php echo e($i); ?>-check" type="checkbox"
                                                class="table-input comboChek">
                                        </div>
                                    </td>
                                <?php elseif($j < 8 || $col2 - 4 < $j): ?>
                                    <?php
                                        $readonly = false;
                                        if ($j - 1 == 0) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-combo';
                                            $comboColumn = 'combo';
                                            $type = 'text';
                                        }
                                        if ($j - 1 == 1) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-color';
                                            $comboColumn = 'color';
                                            $type = 'text';
                                        }
                                        if ($j - 1 == 2) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-ld';
                                            $comboColumn = 'ld_no';
                                            $type = 'text';
                                        }
                                        if ($j - 1 == 3) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-shade';
                                            $comboColumn = 'shade';
                                            $type = 'text';
                                        }
                                        if ($j - 1 == 4) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-qty';
                                            $comboColumn = 'qty';
                                            $type = 'number';
                                        }
                                        if ($j - 1 == 5) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-ecut';
                                            $comboColumn = 'extra_cutting';
                                            $type = 'number';
                                        }
                                        if ($j - 1 == 6) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-nqty';
                                            $comboColumn = 'new_qty';
                                            $type = 'number';
                                        }
                                        if ($j == $col2 - 3) {
                                            $readonly = true;
                                            $comboId = 'combo' . $combos[$i]['id'] . '-tf';
                                            $comboColumn = 'total_finished';
                                            $type = 'number';
                                        }
                                        if ($j == $col2 - 2) {
                                            $readonly = true;
                                            $comboId = 'combo' . $combos[$i]['id'] . '-tg';
                                            $comboColumn = 'total_gray';
                                            $type = 'number';
                                        }
                                        if ($j == $col2 - 1) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-rmk';
                                            $comboColumn = 'remarks';
                                            $type = 'text';
                                        }
                                    ?>
                                    <td>
                                        <div
                                            style="text-align: center; width: <?php echo e($j == 2 ? $width * 2 : $width); ?>px !important;">
                                            <input
                                                onchange="changeCombo(<?php echo e($combos[$i]['id']); ?>, '<?php echo e($comboColumn); ?>')"
                                                id="<?php echo e($comboId); ?>" type="<?php echo e($type); ?>"
                                                value="<?php echo e(floatFormater($combos[$i][$comboColumn])); ?>"
                                                class="table-input" <?php echo e($readonly ? 'readonly' : ''); ?>

                                                onkeydown="moveMouseFocus(this, event, 'combo', <?php echo e($combos); ?>, '<?php echo e($i); ?>')"
                                                onkeyup="releaseShiftPress()"
                                            >
                                        </div>
                                    </td>
                                <?php else: ?>
                                    <?php
                                        $fabricId = $fabrications[$fabricCol]['id'];
                                        if ($j % 2 == 0) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-fabric' . $fabrications[$fabricCol]['id'] . '-rf';
                                        }
                                        if ($j % 2 == 1) {
                                            $comboId = 'combo' . $combos[$i]['id'] . '-fabric' . $fabrications[$fabricCol++]['id'] . '-rg';
                                        }
                                        $yarnAllocationsColumnValue = null;
                                        $readonly = 'readonly';

                                        if (isset($yarnAllocations[$allocationId]) && $yarnAllocations[$allocationId]['fabric_id'] == $fabrications[$fabricDx]['id']) {
                                            if ($j % 2 == 0) {
                                                $yarnAllocationsColumnValue = $yarnAllocations[$allocationId]['req_finished'];
                                            }
                                            if ($j % 2 == 1) {
                                                $yarnAllocationsColumnValue = $yarnAllocations[$allocationId]['req_gray'];
                                                $allocationId++;
                                            }
                                            $readonly = null;
                                        }
                                        if ($j % 2 == 1) {
                                            $fabricDx++;
                                        }
                                    ?>
                                    <td>
                                        <div style="text-align: center; width: <?php echo e($width); ?>px !important;">
                                            <input
                                                onchange="changeCombo(<?php echo e($combos[$i]['id']); ?>, '<?php echo e($j % 2 == 0 ? 'rf' : 'rg'); ?>', <?php echo e($fabricId); ?>)"
                                                id="<?php echo e($comboId); ?>" type="number"
                                                value="<?php echo e(floatFormater($yarnAllocationsColumnValue)); ?>"
                                                class="table-input" <?php echo e($readonly ?? ''); ?>

                                                onkeydown="moveMouseFocus(this, event, 'combo', <?php echo e($combos); ?>, '<?php echo e($i); ?>')"
                                                onkeyup="releaseShiftPress()"
                                            >
                                        </div>
                                    </td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </tr>
                    <?php endfor; ?>
                    <tr>
                        <?php
                            $fabricCol = 0;
                            $tf = 0;
                            $tg = 0;
                        ?>
                        <?php for($j = 0; $j < $col2 - 7; $j++): ?>
                            <?php if($j == 0): ?>
                                <td colspan="8">Total</td>
                            <?php elseif($j < $col2 - 10): ?>
                                <?php

                                    if ($j % 2 == 1) {
                                        $id = $fabrications[$fabricCol]['id'] . '-tf';
                                        $vlo = $fabrications[$fabricCol]['total_finished'];
                                        $tf += $vlo;
                                    }
                                    if ($j % 2 == 0) {
                                        $id = $fabrications[$fabricCol]['id'] . '-tg';
                                        $vlo = $fabrications[$fabricCol++]['total_gray'];
                                        $tg += $vlo;
                                    }
                                ?>
                                <td>
                                    <div style="text-align: center; width: <?php echo e($width); ?>px !important;">
                                        <input id="<?php echo e($id); ?>" type="number"
                                            value="<?php echo e(floatFormater($vlo)); ?>" class="table-input" readonly>
                                    </div>
                                </td>
                            <?php elseif($j < $col2 - 8): ?>
                                <?php
                                    if ($j % 2 == 1) {
                                        $id = 'tf';
                                        $vlo = $tf;
                                    }
                                    if ($j % 2 == 0) {
                                        $id = 'tg';
                                        $vlo = $tg;
                                    }
                                ?>
                                <td>
                                    <div style="text-align: center; width: <?php echo e($width); ?>px !important;">
                                        <input id="<?php echo e($id); ?>" type="number"
                                            value="<?php echo e(floatFormater($vlo)); ?>" class="table-input" readonly>
                                    </div>
                                </td>
                            <?php else: ?>
                                <td></td>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </tr>
                </tbody>
            </table>


            <div>
                <div class="d-inline">
                    <button class="btn btn-primary" onclick="getTable(true,null)">+</button>
                </div>

                <p class="d-inline" style="font-size: 10px; padding: 0px; color: black; margin-top: 5px;">Booking
                    Based On Knitting & Dyeing Process Loss
                    <span>
                        <input onchange="changeYarnBookingData(<?php echo e($orderId); ?>, 'processLose')" type="number"
                            min="0" value="<?php echo e(floatFormater($yarnBooking->process_loss ?? '')); ?>"
                            id="process_loss"
                            style="width: 30px; margin-left: 5px;font-size: 12px; font-weight: bold; text-align: center;">
                        %
                    </span>
                    Extra Cutting-
                    <span>
                        <input onchange="changeYarnBookingData(<?php echo e($orderId); ?>, 'processLose')" type="number"
                            min="0" value="<?php echo e(floatFormater($yarnBooking->extra_cutting ?? '')); ?>"
                            id="extra_cutting"
                            style="width: 30px; margin-left: 5px;font-size: 12px; font-weight: bold; text-align: center;">
                        %
                    </span>
                </p>

            </div>


            <div class="row">
                <div class="col-4" style="font-size:12px;">
                    <div style="font-size: 12px; color: black; margin-top: 10px; white-space: normal;">

                        <span>1. Please strictly maintain the above mentioned DIA & GSM</span><br>
                        <span>2. Color Fastness, rubbing and chemical test should be Pass.</span><br>
                        <span>3. SHRINKAGE & GSM ALLOW BELLOW ±5% (After wash)***</span>

                    </div>
                </div>
                <div id="remarkList" class="col-4" style="font-size:12px;">


                </div>

                <div class="col-4 d-flex" style="font-size:12px; justify-content: end;">
                    <div id="summery" style="display:inline;">

                    </div>

                </div>

            </div>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/yarn/yarnBookingTable.blade.php ENDPATH**/ ?>