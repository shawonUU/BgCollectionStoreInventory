<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/BG-Collection-logo-.png')); ?>">
    <title>Inventory Report</title>
    <style>
.table {
    width: 100%;
    /* border: 1px solid #000000; */
    border-spacing: 0;
}
.table td, .table th {
    font-size: 9px;
    font-weight: bold;
    text-align: center;
    padding: 3px;
    vertical-align: top;
    border-top: 1px solid #000000;
    border-left: 1px solid #000000;
    /* border-right: 1px solid #000000; */
}

.table tr:last-child td {
    color:red;
}


h2 {
    text-transform: uppercase;
}

.text-center {
    font-size: 18px;
    text-align: center;
}

.p-25 {
    padding: 25px;
}

.pr-5 {
    padding-right: 15px;
}

.ml-3 {
    margin-left: 9px;
}

.text-capitalize {
    text-transform: capitalize
}

.text-right {
    text-align: right;
}

.mt-25 {
    margin-top: 25px;
}

.title {
    font-size: 15px;
    font-weight: 600;
    line-height: 25px;
    padding: 5px 20px;
    background: #CFCFCF;
    margin: 0;
}
.text-uppercase {
    text-transform: uppercase;
}
    </style>
</head>

<body>

    <div class="br-pagebody mg-t-5 pd-x-30">

        <div class="br-section-wrapper mt-5">
            <div  class="d-flex justify-content-end  align-items-center mb-4">
                <div>
                    
                <?php if(auth()->user()->role_id == 6): ?>
                <a href="<?php echo e(route('add.order')); ?>" class="btn btn-sm btn-primary text-white"><i class=""></i><span class="pl-2">Add Order</span></a>
                <?php endif; ?>
                <a href="<?php echo e(route('order.management')); ?>" class="ml-2 btn btn-sm btn-warning     text-white"><i class=""></i><span class="pl-2">Running Orders</span>
                </a>
                </div>
        </div>
            <table class="table" id="datatable">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Job No</th>
                    <th scope="col">Buyer Name</th>
                    <th scope="col">Merchandiser</th>
                    <th scope="col">Fabrication</th>
                    <th scope="col">Order No</th>
                    <th scope="col">Order Qty</th>
                    <th scope="col">Unit Price</th>
                    <th scope="col">Total</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $shiftOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($item->job_no); ?></td>
                        <td><?php echo e($item->buyer_name); ?></td>
                        <td><?php echo e($item->merchandiser); ?></td>
                        <td><?php echo e($item->fabrication); ?></td>
                        <td><?php echo e($item->order_no); ?></td>
                        <td><?php echo e($item->order_qty); ?></td>
                        <td><?php echo e($item->unit_price); ?></td>
                        <td><?php echo e($item->total); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td>
                            <a href="<?php echo e(route('edit.shifted.order',encrypt($item->id))); ?>" style="color:black">
                                <i class="fa fa-pencil-square" style="font-size:20px"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>


    </div>



        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script>
            $(document).ready(function() {
                // alert('hello');
                $("#buyerSelect").select2({
                    tags: true
                });
                $("#status").select2({
                    tags: true
                });

            });
            $("#datatable").DataTable();

            function  editModal(){

                // alert('hello');
                // let id = $('#'+'style_no').val();
                // $('#'+'styleSeeder').val(id);
                // document.getElementById('styleSeeder').dispatchEvent(new Event('change'));
            }
        </script>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/pdf/shiftedOrder.blade.php ENDPATH**/ ?>