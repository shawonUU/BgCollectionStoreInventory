<table class="table table-hover table-responsive" id="mm_table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Style</th>
        <th scope="col">Accessories</th>
        <th scope="col">Unit</th>
        <th scope="col">Color</th>
        <th scope="col">Size</th>
        <th scope="col">Supplier</th>
        <th scope="col">Callan No</th>
        <th scope="col">MRR No</th>
        <th scope="col">Collected By</th>
        <th scope="col">Qty</th>
        <th scope="col">Date</th>
        <th scope="col">Actions</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $stockInHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mrr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($mrr->style_no); ?></td>
            <td><?php echo e($mrr->accessories_name); ?></td>
            <td><?php echo e($mrr->unit); ?></td>
            <td><?php echo e($mrr->color_name??'N/A'); ?></td>
            <td><?php echo e($mrr->size??'N/A'); ?></td>
            <td><?php echo e($mrr->supplier_name); ?></td>
            <td><?php echo e($mrr->callan_no); ?></td>
            <td><?php echo e($mrr->mrr_no); ?></td>
            <td><?php echo e($mrr->collected_by); ?></td>
            <td><?php echo e(floatFormater($mrr->quantity)); ?></td>
            <td><?php echo e($mrr->received_date); ?></td>
            <td><a href="<?php echo e(route('mrr_view', Crypt::encrypt($mrr->id) )); ?>" class="btn btn-sm btn-primary">Edit</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/store/mrrTable.blade.php ENDPATH**/ ?>