<?php
    $dashboard = true;
?>

<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">
        <div class="br-section-wrapper mt-4">
            <div class="d-flex justify-content-between">
                <div>
                    <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Booking </h6>
                    <p class="mg-b-25 mg-lg-b-50">Booking Accessories</p>
                </div>
                <div>
                    <a class="btn btn-warning" href="<?php echo e(route('style.create')); ?>"><i class="fa fa-plus"></i> Add Style</a>
                </div>
            </div>
            <form id="bookingForm">
                <div class="row">
                    <div class="col-lg-4 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Style Number </strong> <span class="text-danger">*</span></label>
                        <select class="form-control is_invalid" id="style_no" name="style_no" onchange="getInventory()">
                            <option value="" selected>--Select Style--</option>
                            <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option <?php echo e(old('style_no') == $style->id ? 'selected' : ''); ?> value="<?php echo e($style->id); ?>">
                                    <?php echo e($style->style_no . ' (' .$style->order_no .' , '. $style->buyer_name . ')' . ' '.$style->created_at->format('My')); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span id="styleNoError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-4 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Accessories Name</strong> <span class="text-danger">*</span></label>
                        <select id="accessories_name" class="form-control select2" onchange="getUnit(this.value)"
                            name="accessories_name">
                            <option value="" selected disabled hidden>--Select Accessories--</option>
                            <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('accessories_name') == $accessory->id ? 'selected' : ''); ?>

                                    value="<?php echo e($accessory->id); ?>">
                                    <?php echo e($accessory->accessories_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span id="accessoriesNameError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-4 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Unit</strong> <span class="text-danger">*</span></label>
                        <select id='unit' class='form-control select2' name='unit'>
                            <option value="" selected disabled hidden>--Select Unit--</option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option id="unitId<?php echo e($unit->id); ?>" <?php echo e(old('unit') == $unit->id ? 'selected' : ''); ?>

                                    value="<?php echo e($unit->id); ?>">
                                    <?php echo e($unit->unit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span id="unitError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-4 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Bar/Ean Code</strong> </label>
                        <input id="bar_or_ean_code" class="form-control" value="<?php echo e(old('bar_or_ean_code')); ?>"
                            placeholder="Enter Bar or Ean Code" type="text" name="bar_or_ean_code">
                        <span id="barOrEanCodeError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-4 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Color</strong></label>
                        <select id="color" class="form-control select2" name="color">
                            <option value="" selected>--Select Color--</option>
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('color') == $color->id ? 'selected' : ''); ?> value="<?php echo e($color->id); ?>">
                                    <?php echo e($color->color_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span id="colorError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-4 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Size</strong> </label>
                        <select id="size" class="form-control select2" name="size">
                            <option value="" selected>--Select Size--</option>
                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('size') == $size->id ? 'selected' : ''); ?> value="<?php echo e($size->id); ?>">
                                    <?php echo e($size->size); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span id="sizeError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-3 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Garments Quantity</strong> <span class="text-danger">*</span></label>
                        <input onchange="change()" id="garments_quantity" class="form-control" type="number" min="1"
                            value="<?php echo e(old('garments_quantity') ? old('garments_quantity') : 1); ?>"
                            placeholder="Garments Quantity" name="garments_quantity">
                        <span id="garmentsQuantityError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-3 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Consumption</strong> <span class="text-danger">*</span></label>
                        <input id="consumption" onchange="change()" class="form-control"type="number" min="0" step="0.1"
                            value="<?php echo e(old('consumption') ? old('consumption') : 1); ?>" name="consumption">
                        <span id="consumptionError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-3 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Tolerance</strong></label>
                        <div class="input-group">
                            <input id="tolerance" onchange="change()" type="number" min="1" max="20"
                                class="form-control" value="<?php echo e(old('tolerance') ? old('tolerance') : 1); ?>">
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">%</span>
                            </div>
                        </div>
                        <span id="toleranceError" class="text-danger"> </span>
                    </div>
                    <div class="col-lg-3 col-xs-6 col-sm-6 mb-3 ">
                        <label class=""><strong>Required Quantity</strong> <span
                                class="text-danger">*</span></label>
                        <input id="requered_quantity"  class="form-control"
                            value="<?php echo e(old('requered_quantity')); ?>" type="number" name="requered_quantity">
                        <span id="requeredQuantityError" class="text-danger"> </span>
                    </div>
                    
                </div>
                <a href="javascript:void(0)" onclick="confirmBooking()" id="submitBooking" class="btn btn-primary mt-3"
                    type="submit"><?php echo submitBtn(); ?></a>
            </form>
        </div>
        <div id="booking-list">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".select2").select2({
                tags: true
            });
            $("#style_no").select2();
            requiredQty();
            // get Unit
            $accessories_id = $('#accessories_name').val();
            getUnit($accessories_id);
            if ($('#style_no').val()) {
                getInventory();
            }
        });


        function preview(file) {
            var file = $("input[type=file]").get(0).files;
            if (file) {
                var reader = new FileReader();

                reader.onload = function() {
                    $("#previewPhoto").css({
                        "width": "50px",
                        "height": "50px",
                        "margin-top": "24px"
                    });
                    $("#previewPhoto").attr("src", reader.result);
                }
                reader.readAsDataURL(file);
            }
        }

        function ajaxSetup() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        }

        function getUnit(id) {
            ajaxSetup();
            $.ajax({
                type: "post",
                url: '<?php echo e(route('unit.get')); ?>',
                data: {
                    id: id
                },
                success: function(data) {
                    if (data) {

                        $('#unit').select2('val', data);
                        $('#unit').attr('disabled', true);
                    } else {
                        $('#unit').select2('val', 0);
                        $('#unit').attr('disabled', false);
                    }
                }
            });
        }

        // $('#accessories_name').change(function() {
        //     var id = $(this).val();
        //     getUnit(id);
        // });
        // success alert
        function succcessAlert(message = 'success') {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })
            Toast.fire({
                icon: 'success',
                title: message,
            })
        }

        // booking
        // $('#submitBooking').click(function() {
        //     $('#unit_id').attr('disabled', false);
        //     var garments_quantity = $('#garments_quantity').val();
        //     var requered_quantity = $('#requered_quantity').val();
        //     confirmData(submitBooking(), 'Garments quantity = ' + garments_quantity,
        //         'Requered quantity =' + requered_quantity);
        // });
        function confirmBooking() {
            $('#unit_id').attr('disabled', false);
            var garments_quantity = $('#garments_quantity').val();
            var requered_quantity = $('#requered_quantity').val();
            confirmData(submitBooking, 'Garments quantity = ' + garments_quantity,
                'Requered quantity =' + requered_quantity);
        }

        var submitBooking = function() {
            var style_no = $('#style_no').val();
            var accessories_name = $('#accessories_name').val();
            var unit = $('#unit').val();
            var color = $('#color').val();
            var size = $('#size').val();
            var garments_quantity = $('#garments_quantity').val();
            var requered_quantity = $('#requered_quantity').val();
            // new
            var bar_or_ean_code = $('#bar_or_ean_code').val();
            var consumption = $('#consumption').val();
            var tolerance = $('#tolerance').val();

            ajaxSetup();
            $.ajax({
                type: "post",
                url: '<?php echo e(route('booking.store')); ?>',
                data: {
                    style_no: style_no,
                    accessories_name: accessories_name,
                    unit: unit,
                    color: color,
                    size: size,
                    garments_quantity: garments_quantity,
                    requered_quantity: requered_quantity,
                    // new
                    bar_or_ean_code: bar_or_ean_code,
                    consumption: consumption,
                    tolerance: tolerance,

                },
                success: function(results) {
                    if (results.success) {
                        succcessAlert('Booking success');
                        getInventory();
                    }
                    if (results.error) {
                        bookingError(results.error);
                    }
                    $('#style_no').removeClass('is-invalid');
                    $('#styleNoError').html('');
                    $('#accessories_name').removeClass('is-invalid');
                    $('#accessoriesNameError').html('');
                    $('#unit').removeClass('is-invalid');
                    $('#unitError').html('');
                    $('#color').removeClass('is-invalid');
                    $('#colorError').html('');
                    $('#size').removeClass('is-invalid');
                    $('#sizeError').html('');
                    $('#garments_quantity').removeClass('is-invalid');
                    $('#garmentsQuantityError').html('');
                    $('#requered_quantity').removeClass('is-invalid');
                    $('#requeredQuantityError').html('');
                    // new validation
                    $('#bar_or_ean_code').removeClass('is-invalid');
                    $('#barOrEanCodeError').html('');
                    $('#consumption').removeClass('is-invalid');
                    $('#consumptionError').html('');
                    $('#tolerance').removeClass('is-invalid');
                    $('#toleranceError').html('');

                    if (results.style_no) {
                        $('#style_no').addClass('is-invalid');
                        $('#styleNoError').html(results.style_no);
                    }
                    if (results.accessories_name) {
                        $('#accessories_name').addClass('is-invalid');
                        $('#accessoriesNameError').html(results.accessories_name);
                    }
                    if (results.unit) {
                        $('#unit').addClass('is-invalid');
                        $('#unitError').html(results.unit);
                    }
                    if (results.color) {
                        $('#color').addClass('is-invalid');
                        $('#colorError').html(results.color);
                    }
                    if (results.size) {
                        $('#size').addClass('is-invalid');
                        $('#sizeError').html(results.size);
                    }
                    if (results.garments_quantity) {
                        $('#garments_quantity').addClass('is-invalid');
                        $('#garmentsQuantityError').html(results.garments_quantity);
                    }
                    if (results.requered_quantity) {
                        $('#requered_quantity').addClass('is-invalid');
                        $('#requeredQuantityError').html(results.requered_quantity);
                    }
                    // new
                    if (results.bar_or_ean_code) {
                        $('#bar_or_ean_code').addClass('is-invalid');
                        $('#barOrEanCodeError').html(results.bar_or_ean_code);
                    }
                    if (results.consumption) {
                        $('#consumption').addClass('is-invalid');
                        $('#consumptionError').html(results.consumption);
                    }
                    if (results.tolerance) {
                        $('#tolerance').addClass('is-invalid');
                        $('#toleranceError').html(results.tolerance);
                    }
                },
            });
        }
        // $("#style_no").change(function() {
        //     getInventory();
        // });

        function getInventory() {
            var style_id = $('#style_no').val();
            ajaxSetup();
            $.ajax({
                type: "post",
                url: '<?php echo e(route('inventory.get')); ?>',
                data: {
                    style_id: style_id,
                },
                success: function(results) {
                    $('#booking-list').html(results);
                    $()
                },
            });
        }

        function bookingError(err_msg) {

            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: err_msg,
            });

        }

        function change() {
            requiredQty();
        }

        function requiredQty() {
            var g_qty = $('#garments_quantity').val();
            var composition = $('#consumption').val();
            var tolerance = $('#tolerance').val();
            var total = g_qty * composition;
            var requered_quantity = total + total * (tolerance / 100);
            var rQty = Math.ceil(requered_quantity);
            // alert(requered_quantity);
            $('#requered_quantity').val(rQty);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/dashboard.blade.php ENDPATH**/ ?>