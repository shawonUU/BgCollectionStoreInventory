
<?php
    $order_list = true;
?>

<?php $__env->startSection('css'); ?>
    <link href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet" />
    <style>
        .ancor_link{
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">
        <div class="br-section-wrapper mt-4">
            <div class="d-flex justify-content-between  mb-3">
                <div>
                    <h2 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Search buyer wise orders</h2>
                </div>
                <div>
                    <?php echo $__env->make('mr.short_code.backbutton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="row mb-5">
                <div class="col-lg-6 col-xs-6 col-sm-6">
                    <select class="form-control" id="buyerId" onchange="redirect()">
                        <option selected value="">All Buyer</option>
                        <?php $__currentLoopData = DB::table('buyers')->get(['id', 'buyer_name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($buyer_id == $buyer->id ? 'selected' : ''); ?>

                                value="<?php echo e(Crypt::encrypt($buyer->id)); ?>">
                                <?php echo e($buyer->buyer_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            

            <div id="order_table" class="table-responsive">
                <?php echo $__env->make('mr.short_code.order_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });

        function redirect() {
            var buyerId = $('#buyerId').val();
            window.location.href = "<?php echo e(route('order.list')); ?>" + '/' + buyerId;
        }
        function anchorTag(link){
            window.location = link;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/orders.blade.php ENDPATH**/ ?>