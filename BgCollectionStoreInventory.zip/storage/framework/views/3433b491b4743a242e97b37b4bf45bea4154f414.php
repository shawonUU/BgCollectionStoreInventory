<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/BG-Collection-logo-.png')); ?>">
    <title>Inventory Report</title>
    <style>
.table {
    width: 100%;
    /* border: 1px solid #000000; */
    border-spacing: 0;
}
.table td, .table th {
    font-size: 9px;
    font-weight: bold;
    text-align: center;
    padding: 3px;
    vertical-align: top;
    border-top: 1px solid #000000;
    border-left: 1px solid #000000;
    /* border-right: 1px solid #000000; */
}

.table tr:last-child td {
    color:red;
}


h2 {
    text-transform: uppercase;
}

.text-center {
    font-size: 18px;
    text-align: center;
}

.p-25 {
    padding: 25px;
}

.pr-5 {
    padding-right: 15px;
}

.ml-3 {
    margin-left: 9px;
}

.text-capitalize {
    text-transform: capitalize
}

.text-right {
    text-align: right;
}

.mt-25 {
    margin-top: 25px;
}

.title {
    font-size: 15px;
    font-weight: 600;
    line-height: 25px;
    padding: 5px 20px;
    background: #CFCFCF;
    margin: 0;
}
.text-uppercase {
    text-transform: uppercase;
}
    </style>
</head>

<body>
    <table class="table" style="color:#000; margin-top:-30px;">
        <thead>
            <tr>
                <td colspan="10" style="border: 1px solid #fff;">
                    <p class="text-right" style="font-size: 13px; font-weight: 600;">Date: <span class="ml-3"><?= date('d/m/Y') ?></span></p>
                    <h2 class="text-center">BG Collection ltd</h2>
                    <div class="text-center " style="margin-bottom:20px;">
                        <span class="text-capitalize"><span class="title">Export Calender Status</span>
                    </div>
                </td>
            </tr>
            <tr class="table-header">
                <th scope="col">#SL</th>
                <th scope="col">JOB NO</th>
                <th scope="col">BUYER</th>
                <th scope="col">Merchandiser</th>
                <th scope="col">Febrication</th>
                <th scope="col">Order No</th>
                <th scope="col">Order Qty</th>
                <th scope="col">Unit Price</th>
                <th scope="col">Total</th>
                <th style="border-right: 1px solid #000" scope="col">Status</th>
            </tr>
        </thead>
        <tbody style="margin:0;padding:0">
            <?php
                $monthlyOrderAmount=0;
                $totalOrderAmount=0;
                $monthlyOrderQty=0;
                $totalOrderQty=0;
            ?>

                <?php
                    $serial = 1;
                ?>
            <?php $__currentLoopData = $exportCalenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $monthlyOrderAmount+=$item->total;
                    $totalOrderAmount+=$item->total;
                    $monthlyOrderQty+=$item->order_qty;
                    $totalOrderQty+=$item->order_qty;

                ?>
                <?php if($loop->index == 0): ?>
                    <tr>
                        <td colspan="10" align="center" style="font-weight:bold;border-right: 1px solid #000"><?php echo e(date('F-Y',strtotime($item->month))); ?></td>
                    </tr>
                <?php endif; ?>

                <tr>
                    <td><?php echo e($serial++); ?></td>
                    <td><?php echo e($item->job_no); ?></td>
                    <td><?php echo e($item->buyer_name); ?></td>
                    <td><?php echo e($item->merchandiser); ?></td>
                    <td><?php echo e($item->fabrication); ?></td>
                    <td><?php echo e($item->order_no); ?></td>
                    <td><?php echo e($item->order_qty); ?></td>
                    <td>$<?php echo e($item->unit_price); ?> </td>
                    <td>$<?php echo e($item->total); ?> </td>
                    <td style="border-right: 1px solid #000"><?php echo e($item->status); ?></td>
                </tr>
                <?php if($loop->index==count($exportCalenders)-1 || date('m-Y',strtotime($item->month)) != date('m-Y',strtotime($exportCalenders[$loop->index+1]->month))): ?>
                    <?php
                        $serial = 1;
                    ?>
                    <tr><td style="border-right: 1px solid #000"colspan="10" height="10"></td></tr>
                    <tr style="background:rgb(160 201 248)">
                        <td colspan="6" style="font-weight:bold;color:#000; text-align:left">Total</td>
                        <td style="font-weight:bold;color:#000"><?php echo e($monthlyOrderQty); ?></td>
                        <td></td>
                        <td><span style="font-weight:bold;color:#000">$<?php echo e($monthlyOrderAmount); ?></span></td>
                        <td style="border-right: 1px solid #000" colspan="2"></td>
                    </tr>
                    <tr>
                        <?php if($loop->index == count($exportCalenders)-1 ): ?>
                        <td  style="border-right: 1px solid #000" align="center" colspan="10" height="10" ><b></b></td>
                        <?php else: ?>
                        <td style="border-right: 1px solid #000" align="center" colspan="10" ><b><?php echo e(date('F-Y',strtotime($exportCalenders[$loop->index+1]->month))); ?></b></td>
                        <?php endif; ?>
                    </tr>
                    <?php
                        $monthlyOrderQty=0;
                        $monthlyOrderAmount=0;
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr style="background:#d07236">
                <td colspan="6" style="font-weight:bold;color:#000; text-align:left">Grand Total</td>
                <td style="font-weight:bold;color:#000"><?php echo e($totalOrderQty); ?></td>
                <td></td>
                <td><span style="font-weight:bold;color:#000">$<?php echo e($totalOrderAmount); ?></span></td>
                <td style="border-right: 1px solid #000" colspan="2"></td>
            </tr>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/pdf/exportCalender.blade.php ENDPATH**/ ?>