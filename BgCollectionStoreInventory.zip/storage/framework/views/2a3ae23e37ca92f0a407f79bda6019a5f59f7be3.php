<?php
    $stock_out_history = true;
?>


 <?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<link type="text/css" rel="stylesheet" href="https://unpkg.com/vue-next-select/dist/index.min.css" />
<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">

    <div class="br-section-wrapper mt-5">
        <table class="table" id="datatable">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Style No</th>
                <th scope="col">Receiver Name</th>
                <th scope="col">Line no</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stockOuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->style_no); ?></td>
                    <td><?php echo e($item->receiver_name); ?></td>
                    <td><?php echo e($item->line_no); ?></td>
                    <td>
                        <a href="<?php echo e(route('stock-out-history-info',Crypt::encrypt($item->id))); ?>" class="btn btn-sm btn-primary">Details</a>
                       <?php if(auth()->user()->role_id == 4 or auth()->user()->role_id == 3): ?>
                       <a  href="<?php echo e(route('edit_stock_out_info',Crypt::encrypt($item->id))); ?>" class="btn btn-sm btn-primary ml-2">Edit</a>
                       <?php endif; ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>

    </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $(".select2-for").select2({
            tags: false
        });

        $("#datatable").DataTable();

    });

</script>
<script>
      function call(){
        // alert("Hello");
        let id = $('#'+'style_name').val();
        $('#'+'style_name_id').val(id);
        document.getElementById('style_name_id').dispatchEvent(new Event('change'));
    }
     $(document).ready(function() {
        $(".select2-for").select2({
            tags: false
        });

    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/stock_out/stockOutHistory.blade.php ENDPATH**/ ?>