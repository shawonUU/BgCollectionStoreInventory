<div  v-if="stockOutInfos.length > 0" class="row mt-4">
    <div class="col">
        <div class="bd rounded table-responsive p-3">
            <table class="table table-hover mg-b-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Style No</th>
                        <th>Receiver Name</th>
                        <th>Line No</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stockOut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($item->style_no); ?></td>
                        <td><?php echo e($item->receiver_name); ?></td>
                        <td><?php echo e($item->line_no); ?></td>
                        <td><?php echo e($item->date); ?></td>
                        <td>
                            <a   href="<?php echo e(route('downLoadStockOutInfo',Crypt::encrypt($item->id))); ?>" target="_blank"  class="btn btn-sm btn-primary">Download</a>
                            <a   href="<?php echo e(route('print-stockout-info',Crypt::encrypt($item->id))); ?>"  target="_blank"  class="btn btn-sm btn-primary ml-2">Print</a>
                       </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/stock_out/stockOutHistories.blade.php ENDPATH**/ ?>