<div class="br-section-wrapper mt-4">
    <div class="d-flex justify-content-between">
        <div>
            <h3 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Booking of <span class="text-info">
                    <?php echo e($style->style_no); ?></span></h3>
        </div>
    </div>
    <div id="booking_info">
        <div id="stock_in_section"  class="table-responsive">
            <?php if($inventories->count()): ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Accessories</th>
                            <th scope="col">Unit</th>
                            <th scope="col">Color </th>
                            <th scope="col">Size</th>
                            <th scope="col">Bar or Ean Code</th>
                            <th scope="col">G.Qty</th>
                            <th scope="col">Consumption </th>
                            <th scope="col">Tolerance </th>
                            <th scope="col">Req Qty</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $requered_quantity =  $inventory->requered_quantity;
                            $received_quantity =  $inventory->received_quantity;
                            $balance =   $received_quantity  - $requered_quantity;
                            $stock_quantity =  $inventory->stock_quantity ;
                        ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($inventory->accessories_name); ?></td>
                                <td><?php echo e($inventory->unit ? $inventory->unit :'N/A'); ?></td>
                                <td><?php echo e($inventory->color_name ?$inventory->color_name  :'N/A'); ?></td>
                                <td><?php echo e($inventory->size ? $inventory->size : 'N/A'); ?></td>
                                <td><?php echo e($inventory->bar_or_ean_code ? $inventory->bar_or_ean_code : 'N/A'); ?></td>
                                <td><span class="badge bg-primary"><?php echo e(floatFormater($inventory->garments_quantity)); ?></span></td>
                                <td><span class="badge bg-secondary"><?php echo e(floatFormater($inventory->consumption)); ?></span></td>
                                <td><span class="badge bg-info"><?php echo e(floatFormater($inventory->tolerance) .'%'); ?></span></td>
                                <td><span class="badge bg-success"><?php echo e(floatFormater($requered_quantity)); ?> </span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php else: ?>
                <h5 class="text-center text-danger text-capitalize mt-4 "> booking or inventory not found</h5>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/style_wise_booking.blade.php ENDPATH**/ ?>