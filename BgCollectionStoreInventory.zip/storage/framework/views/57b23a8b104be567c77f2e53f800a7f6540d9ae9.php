<?php
    $search_booking = true;
?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">
        <div class="br-section-wrapper mt-5">
            <div class="d-flex justify-content-between  mb-3">
                <div>
                    <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Stock Histories</h6>
                </div>
                <div>
                    <?php echo $__env->make('mr.short_code.backbutton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div id="stock_in_section"  class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Style No</th>
                            <th scope="col">Accessories Name</th>
                            <th scope="col">Unit</th>
                            <th scope="col">Color Name</th>
                            <th scope="col">Size</th>
                            <th scope="col">Supplier Name</th>
                            <th scope="col">Callan No</th>
                            <th scope="col">MRR No</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Collected By</th>
                            <th scope="col">Date</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $stock_in_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_in_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($stock_in_history->style_no); ?></td>
                                <td><?php echo e($stock_in_history->accessories_name); ?></td>
                                <td><?php echo e($stock_in_history->unit); ?></td>
                                <td><?php echo e($stock_in_history->color_name); ?></td>
                                <td><?php echo e($stock_in_history->size); ?></td>
                                <td><?php echo e($stock_in_history->supplier_name); ?></td>
                                <td><?php echo e($stock_in_history->callan_no); ?></td>
                                <td><?php echo e($stock_in_history->mrr_no); ?></td>
                                <td><?php echo e($stock_in_history->quantity); ?></td>
                                <td><?php echo e($stock_in_history->collected_by); ?></td>
                                <td><?php echo e($stock_in_history->received_date); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/stock_histories.blade.php ENDPATH**/ ?>