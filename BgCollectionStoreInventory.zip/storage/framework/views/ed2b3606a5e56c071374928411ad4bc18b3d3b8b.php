<a href="<?php echo e(route('stockOutCreate')); ?>" class="br-menu-link  <?php echo e(isset($stockOutCreate) ? 'active' : ''); ?>">
    <div class="br-menu-item">
        <i class="menu-item-icon ion-briefcase tx-24"></i>
        <span class="menu-item-label">Stock Out</span>

    </div>
</a>
<a href="<?php echo e(route('stock_out_history')); ?>" class="br-menu-link <?php echo e(isset($stock_out_history) ? 'active' : ''); ?>">
    <div class="br-menu-item">
        <i class="menu-item-icon icon ion-document-text tx-24"></i>
        <span class="menu-item-label">Stock Out History</span>

    </div>
</a>
<a href="<?php echo e(route('receivers')); ?>" class="br-menu-link  <?php echo e(isset($receivers) ? 'active' : ''); ?>">
    <div class="br-menu-item">
        <i class="menu-item-icon icon ion-ios-person-outline tx-24"></i>
        <span class="menu-item-label">Receivers</span>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/stock_out/sidebar.blade.php ENDPATH**/ ?>