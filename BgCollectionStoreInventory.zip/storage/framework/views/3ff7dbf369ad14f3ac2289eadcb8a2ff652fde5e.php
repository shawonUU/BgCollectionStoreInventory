<?php
    $yarn_booking = true;
?>

<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="br-pagebody mg-t-5 pd-x-30">
        <div class="br-section-wrapper mt-5">
            <div class="d-flex justify-content-between">
                <div>
                    <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Order List</h6>
                </div>
                <div>
                    <a class="btn btn-warning" href="<?php echo e(route('order.create')); ?>"><i class="fa fa-plus"></i>Add Order</a>
                </div>
            </div>

           <div class="d-none justify-content-end mb-3">
                <div>
                    <label for="" style>Search</label>
                    <input class="form-control" type="search" style="height:2rem;">
                </div>
           </div>

            <div id="mrr_list" style=" width: 100%;">
                <table>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table">
                                <td><?php echo e($order->buyer_name); ?></td>
                                <td><?php echo e($order->order_no); ?></td>
                                <td><a href="<?php echo e(route('yarn_booking', $order->id)); ?>" class="btn btn-sm btn-primary">Booking</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BgCollectionStoreInventory\resources\views/mr/yarn/orderList.blade.php ENDPATH**/ ?>